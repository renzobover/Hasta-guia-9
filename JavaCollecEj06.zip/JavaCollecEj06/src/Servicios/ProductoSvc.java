/*
Se necesita una aplicación para una tienda en la cual queremos almacenar los distintos
productos que venderemos y el precio que tendrán. Además, se necesita que la
aplicación cuente con las funciones básicas.
Estas las realizaremos en el servicio. Como, 
introducir un elemento, 
modificar su precio,
eliminar un producto
mostrar los productos que tenemos con su precio (Utilizar Hashmap). 
El HashMap tendrá de llave el nombre del producto y de valor el precio.
Realizar un menú para lograr todas las acciones previamente mencionadas.
 */
package Servicios;

import Entidades.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author A308862
 */
public class ProductoSvc {
    
    
    Scanner scn = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");   
    
    HashMap<String, Producto> productoMap = new HashMap();
 
    String opc = "";
    
    
    public void crearProducto() {
        
        String nombre="";
        double precio=0;
                
        Producto prod = new Producto();
        
        System.out.println("Nombre del Producto :");
        nombre=scn.next();
        
        System.out.println("Precio :");
        prod.prodPrecio=scn.nextDouble();
        
        productoMap.put(nombre, prod);
        
    }

    public void elimProducto() {
        String nombre="";
        System.out.println("Nombre del Producto :");
        nombre=scn.next();

        System.out.println("Esta seguro de eliminar el producto " + nombre + "(S/N)?:" );
        do {
            opc=scn.next();
        } while (!opc.equalsIgnoreCase("S") && !opc.equalsIgnoreCase("N"));
        
        if (opc.equalsIgnoreCase("S")) {
            productoMap.remove(nombre);
        }
    }
    
    public void modifPrecio() {

        String nombre="";
        double precio=0;
               
        Producto prod = new Producto();
        
        System.out.println("Nombre del Producto :");
        nombre=scn.next();
        
        System.out.println("Precio actual :" + productoMap.get(nombre).prodPrecio);
        
        System.out.println("Precio nuevo:");
        prod.prodPrecio=scn.nextDouble();

        productoMap.replace(nombre, prod);
        
        
    }

    public void mostrarProductos() {
        
        double precio=0;
        for (Map.Entry<String, Producto> entry : productoMap.entrySet()) {
            System.out.printf("Producto : %s  Precio: $%s", entry.getKey(), entry.getValue().getProdPrecio());
            System.out.println("");
        }
        System.out.println("Fin de Lista de Productos");
        System.out.println("");
        
    }

    public void Menu() {
        int opcmenu = 9;
        do {
            System.out.println("TIENDA  'LA MARINA'");
            System.out.println("===================");
            System.out.println("1-Crea Productos   ");
            System.out.println("2-Modifica Precios ");
            System.out.println("3-Elimina Productos");
            System.out.println("4-Muestra Productos");
            System.out.println("===================");
            System.out.println("0-Salir del Menu   ");
            opcmenu=scn.nextInt();
         switch (opcmenu) {
            case 1:
                crearProducto();
                break;
            case 2:
                modifPrecio();
                break;
            case 3:
                elimProducto();
                break;
            case 4:
                mostrarProductos();
                break;
            case 0:
                System.exit(opcmenu);
                break;

            default:
                throw new AssertionError();
            }                   
        } while (opcmenu != 0 || opcmenu < 5);
        

    }
    
    
    
}
