/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.Objects;

/**
 *
 * @author A308862
 */
public class Producto {

    public String prodNombre;
    public double prodPrecio;

    public Producto() {
    }

    public Producto(String prodNombre, double prodPrecio) {
        this.prodNombre = prodNombre;
        this.prodPrecio = prodPrecio;
    }

    public String getProdNombre() {
        return prodNombre;
    }

    public void setProdNombre(String prodNombre) {
        this.prodNombre = prodNombre;
    }

    public double getProdPrecio() {
        return prodPrecio;
    }

    public void setProdPrecio(double prodPrecio) {
        this.prodPrecio = prodPrecio;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.prodNombre);
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.prodPrecio) ^ (Double.doubleToLongBits(this.prodPrecio) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        if (Double.doubleToLongBits(this.prodPrecio) != Double.doubleToLongBits(other.prodPrecio)) {
            return false;
        }
        if (!Objects.equals(this.prodNombre, other.prodNombre)) {
            return false;
        }
        return true;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
}
