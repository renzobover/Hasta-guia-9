/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej6;

import Servicio.CafeteraServicio;
import java.util.Scanner;

/**
 *
 * @author u543699
 */
public class Ej6 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        CafeteraServicio cs = new CafeteraServicio();
        Cafetera c1= cs.CrearCafetera();
        menu(c1,cs);
        
        
        
    }
    

    public static void menu(Cafetera c1, CafeteraServicio cs){
        Scanner leer = new Scanner(System.in);
        System.out.println("Elija opcion:");
        System.out.println("1. Llenar cafetera");
        System.out.println("2. Servir Taza");
        System.out.println("3. Vaciar cafetera");
        System.out.println("4. Agregar cafe");
        System.out.println("0. Salir");
        
        int op = leer.nextInt();
        while (op!=0){
            switch (op){
                case 1:
                     cs.llenarCafetera(c1);
                     break;
                case 2:
                    cs.servirTaza(c1);
                    break;
                case 3:
                    cs.vaciarCafetera(c1);
                    break;
                case 4:
                    cs.agregarCafe(c1);
                    break;
                case 0:
                    System.out.println("Adios!!");
                    break;
            }
            System.out.println("Elija opcion:");
            System.out.println("1. Llenar cafetera");
            System.out.println("2. Servir Taza");
            System.out.println("3. Vaciar cafetera");
            System.out.println("4. Agregar cafe");
            System.out.println("0. Salir");

            op = leer.nextInt();
        }
    }
}