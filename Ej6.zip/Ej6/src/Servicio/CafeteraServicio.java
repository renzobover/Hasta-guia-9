/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import ej6.Cafetera;
import java.util.Scanner;

/**
 *
 * @author u543699
 */
public class CafeteraServicio {
    public Scanner leer = new Scanner(System.in);
    
    public Cafetera CrearCafetera(){
        Cafetera c1 = new Cafetera();
        System.out.println("Se creo una cafetera con capacidad de 10 cafes pequeños");
        c1.setCapacidadMaxima(10);
        return c1;
    }
    public void llenarCafetera(Cafetera c1){
        c1.setCantidadActual(c1.getCapacidadMaxima());
        System.out.println("La cafetera se lleno con 10");
    }
    public void servirTaza(Cafetera c1){
        System.out.println("Ingrese el tamaño de la taza: 1, 2, 3...10 cafes");
        System.out.println("La cantidad de cafe disponibles son: "+c1.getCantidadActual() );
        int taza=leer.nextInt();
        if (taza>c1.getCantidadActual() ){
            System.out.println("La cantidad actual es "+c1.getCantidadActual());
            System.out.println("Se servira "+ c1.getCantidadActual()+" cafes" );
            c1.setCantidadActual(0);
        }else {
            c1.setCantidadActual(c1.getCantidadActual()-taza);
            
        }
    }
    public void vaciarCafetera(Cafetera c1){
        System.out.println("Se descarto el cafe que habia en la cafetera.");
        System.out.println("Usted derrocho "+c1.getCantidadActual()+" tazas de cafe." );
        c1.setCantidadActual(0);
        
    }
    public void agregarCafe(Cafetera c1){
        System.out.println("La capacidad maxima de la cafetera es:"+c1.getCapacidadMaxima() );
        System.out.println("La cafetera tiene "+c1.getCantidadActual()+ " tazas de cafe" );
        System.out.println("Cuanto cafe desea agregar?");
        int a = leer.nextInt();
        int b=a+c1.getCantidadActual() ;
        
        if (a+c1.getCantidadActual()>=10){
            c1.setCantidadActual(10);
            System.out.println("Se desbordaron "+(b-10)+" tazas de cafe derrochador");
        } else {
            c1.setCantidadActual(b);
        }
    }
    
}
